const baseUrl = "https://otakudesu.cloud"

module.exports = baseUrl